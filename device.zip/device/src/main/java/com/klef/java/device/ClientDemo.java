package com.klef.java.device;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class ClientDemo {
    public static void main(String[] args) {
        Configuration configuration = new Configuration();
        configuration.configure("hibernate.cfg.xml");
        SessionFactory sessionFactory = configuration.buildSessionFactory();

        Session session = sessionFactory.openSession();
        Transaction transaction = session.beginTransaction();

        // Create Device
        Device device = new Device();
        device.setBrand("Generic");
        device.setModel("Device123");
        device.setPrice(500.00);
        session.save(device);

        // Create Smartphone
        Smartphone smartphone = new Smartphone();
        smartphone.setBrand("Samsung");
        smartphone.setModel("Galaxy S23");
        smartphone.setPrice(1000.00);
        smartphone.setOperatingSystem("Android");
        smartphone.setCameraResolution("108 MP");
        session.save(smartphone);

        // Create Tablet
        Tablet tablet = new Tablet();
        tablet.setBrand("Apple");
        tablet.setModel("iPad Air");
        tablet.setPrice(800.00);
        tablet.setScreenSize("10.9 inches");
        tablet.setBatteryLife("10 hours");
        session.save(tablet);

        transaction.commit();
        session.close();

        System.out.println("Records inserted successfully!");
    }
}

